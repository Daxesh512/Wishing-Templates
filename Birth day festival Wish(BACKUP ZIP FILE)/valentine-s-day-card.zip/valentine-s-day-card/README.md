# Valentine's Day Card

A Pen created on CodePen.

Original URL: [https://codepen.io/MohamedDine/pen/XJWWery](https://codepen.io/MohamedDine/pen/XJWWery).

Features :

Multiple Questions:

"Will you be my Valentine?"
"Would you like to go on a date with me?"
"Can I have a hug?"

Playful "No" Button Features:

The "No" button dodges the mouse cursor when hovered over
After 5 dodge attempts, it shows a sad response
The heart changes to a broken heart when rejected
Option to try again after rejection

Progressive Interaction:

Each "Yes" answer leads to the next question
Final acceptance triggers a celebration with floating hearts
Cute emojis added to each question

New Animations and Effects:

Smooth transitions between questions
Random movement of the "No" button
Heart animation changes based on responses